Instead of polluting your `.qmd` file with all of your code, store all your functions in separate aptly-named scritps.

Feel free to create new `.R` files as required by your analysis.
