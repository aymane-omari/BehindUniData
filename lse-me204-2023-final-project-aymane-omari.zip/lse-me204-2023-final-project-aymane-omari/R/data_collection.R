library(rvest)
library(here)
library(purrr)
library(httr)
library(dplyr)
library(stringr)
library(magrittr)

get_top_universities_data <- function(output_file_path,num_universities){

####STEP 1: Get the ranking and name of the university####

# Function to Scrape Top University Data from the CWUR Website
  scrape_cwur_universities <- function(num_universities){
    base_url <- "https://cwur.org/2022-23.php"
    page <- read_html(base_url)
    
    ranking <- lapply(1:num_universities, function(i) {
      xpath <- sprintf('/html/body/div/div[2]/div/div/table/tbody/tr[%d]/td[1]', i)
      page %>% html_nodes(xpath = xpath) %>% html_text(trim = TRUE)
    }) %>% unlist()
    
    name <- lapply(1:num_universities, function(i) {
      xpath <- sprintf('/html/body/div/div[2]/div/div/table/tbody/tr[%d]/td[2]/a[1]', i)
      page %>% html_nodes(xpath = xpath) %>% html_text(trim = TRUE)
    }) %>% unlist()
    
    location <- lapply(1:num_universities, function(i) {
      xpath <- sprintf('/html/body/div/div[2]/div/div/table/tbody/tr[%d]/td[3]', i)
      page %>% html_nodes(xpath = xpath) %>% html_text(trim = TRUE)
    }) %>% unlist()
    
    return(list(ranking = ranking, name = name, location = location))
  }

  # Scrape data
  universities_data <- scrape_cwur_universities(num_universities)
  
  # Create a data frame
  top_universities_df <- data.frame(
    ranking = universities_data$ranking,
    name = universities_data$name,
    location = universities_data$location
  )

  ####STEP 2: Enrich data with Wikipedia information using APIs####
  
  get_college_info <- function(college_name) {
    
    # Perform a search using the college name
    base_search_url <- "https://en.wikipedia.org/w/api.php"
    query_params <- list(
      action = "query",
      format = "json",
      list = "search",
      srsearch = college_name
    )
    
    response <- GET(url = base_search_url, query = query_params)
    
    if (status_code(response) == 200) {
      search_data <- content(response, as = "parsed")
      
      if (length(search_data$query$search) > 0) {
        # Get the title of the first search result
        page_title <- search_data$query$search[[1]]$title
        
        # Format the page title by replacing spaces with underscores
        page_title <- gsub(" ", "_", page_title)
        
        # Fetch page summary data using the formatted page title
        base_summary_url <- "https://en.wikipedia.org/api/rest_v1/page/summary/"
        summary_url <- paste0(base_summary_url, page_title)
        summary_response <- GET(summary_url)
        
        if (status_code(summary_response) == 200) {
          college_info <- content(summary_response, as = "parsed")
          
          # Extract all fields from college_info using pluck with .. prefix
          extracted_values <- college_info
          
          # Add title and description to the extracted_values list
          extracted_values$description <- college_info$extract
          
          # Remove the 'extract' column from the extracted_values list
          extracted_values$extract <- NULL
          
          return(extracted_values)
          
        } else {
          cat(paste("Failed to fetch data for", college_name, ". Status code:", status_code(summary_response), "\n"))
          return(NA)
        }
      } else {
        cat(paste("No search results found for", college_name, "\n"))
        return(NA)
      }
    } else {
      cat(paste("Failed to fetch data for", college_name, ". Status code:", status_code(response), "\n"))
      return(NA)
    }
  }
  # Replace spaces with underscores in the university names
  top_universities_df$name <- str_replace_all(top_universities_df$name, " ", "_")
  
  # Apply the get_college_info function to each university name and gather the results
  enriched_universities_list <- lapply(top_universities_df$name, get_college_info)
  
  # Convert the list of enriched information into a data frame
  enriched_universities_df <- do.call(rbind, enriched_universities_list)
  
  # Combine the enriched information with the original data frame
  enriched_top_universities_df <- cbind(top_universities_df, enriched_universities_df)
  
  
  ####STEP 3: GET MORE SPECIFIC INFO: WEB SCRAPING####
  # Function to perform web scraping for a single university
  scrape_university_info <- function(wikipedia_url) {
    tryCatch({
      webpage <- read_html(wikipedia_url)
      
      # Use CSS selectors or XPath expressions to extract the required information
      university_type <- webpage %>%
        html_nodes("th:contains('Type') + td") %>%
        html_text() %>%
        str_trim()
      
      # Check if university_type is empty and assign NA if it is
      if (length(university_type) == 0) university_type <- NA
      
      founding_date <- webpage %>%
        html_nodes("th:contains('Established') + td") %>%
        html_text() %>%
        str_trim()
      
      # Use regex to extract the founding date correctly
      # Assuming the date formats may vary (e.g., "Month Day, Year" or "Year" or "Month Day, Year; additional text")
      # The following regex pattern captures different date formats
      founding_date <- sub(".*?([A-Za-z]+ \\d{1,2}, \\d{4}).*", "\\1", founding_date)
      founding_date <- sub(".*?(\\d{4}).*", "\\1", founding_date)
      
      # Check if founding_date is empty and assign NA if it is
      if (length(founding_date) == 0) founding_date <- NA
      
      number_of_students <- webpage %>%
        html_nodes("th:contains('Students') + td") %>%
        html_text() %>%
        str_trim()
      
      # Check if number_of_students is empty and assign NA if it is
      if (length(number_of_students) == 0) number_of_students <- NA
      
      
      return(list(
        typeUni = university_type,
        founding_date = founding_date,
        number_of_students = number_of_students
      ))
    }, error = function(e) {
      # Error occurred (e.g., 404 not found), return full NA list
      return(list(
        typeUni = NA,
        founding_date = NA,
        number_of_students = NA
      ))
    })
  }
  
  # Create a new data frame to store the scraped information
  scraped_universities_list <- lapply(paste0("https://en.wikipedia.org/wiki/", enriched_top_universities_df$name), scrape_university_info)
  
  # Convert the list of scraped information into a data frame using bind_rows from dplyr
  scraped_universities_df <- do.call(rbind, scraped_universities_list)
  
  # Combine the scraped information with the original enriched dataset
  final_enriched_dataset <- cbind(enriched_top_universities_df, scraped_universities_df)
  
  final_enriched_dataset <- apply(final_enriched_dataset,2,as.character)
  
  # Save the data frame to a CSV file inside the "raw" subfolder
  write.csv(final_enriched_dataset, file = output_file_path, row.names = FALSE)
}