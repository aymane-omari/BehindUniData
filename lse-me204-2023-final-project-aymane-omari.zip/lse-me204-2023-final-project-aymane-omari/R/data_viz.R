# Use this file to store functions that produce your plots
# Packages used
library(ggplot2)
library(rnaturalearth)
library(dplyr)
library(stringr)
library(tidyverse)

####6: BIG PICTURE####

#Function 1: Type of university vs ranking: distribution of universities by country.

create_universities_map <- function(file_path) {
  # Load the CSV file containing the top universities data
  top_universities_df <- read.csv(file_path, stringsAsFactors = FALSE)
  
  # Replace "usa" with "United States of America" in top_universities_df
  top_universities_df$location <- ifelse(tolower(top_universities_df$location) == "usa", "United States", top_universities_df$location)
  
  # Get the world map data
  worldMap_df <- ne_countries(scale = "medium", returnclass = "sf")
  
  # Clean up the location column in top_universities_df to match the names in worldMap_df
  # Assuming location in top_universities_df is the same as the name in worldMap_df
  top_universities_df$location <- tolower(top_universities_df$location)
  worldMap_df$name <- tolower(worldMap_df$name)
  
  # Create the country_counts_df with all countries and set universities to 0
  country_counts_df <- data.frame(name = worldMap_df$name, universities = 0)
  
  # Compute universities count for countries with data
  country_counts <- table(top_universities_df$location)
  country_counts_df$universities <- as.numeric(country_counts[match(country_counts_df$name, names(country_counts))])
  
  # Perform an inner join to keep only countries with matching keys in both dataframes
  joined_map_data <- inner_join(worldMap_df, country_counts_df, by = "name")
  
  # Create the map plot
  g <- ggplot(data = joined_map_data) +
    geom_sf(aes(fill = universities), color = "white") +
    scale_fill_gradient(low = "#FFFF00", high = "#FF0000", name = "Number of Top Universities",
                        labels = scales::comma) +
    theme_void() +
    theme(legend.position = "bottom", legend.key.width = unit(2, "cm"))
  
  # Titles and captions
  g <- g +
    ggtitle("Countries with the Most Top Universities") +
    labs(subtitle = "Number of Top Universities",
         caption = "Data source: CWUR Universities")  # Add a caption with the data source if desired
  
  # Print the plot
  print(g)
  
  # Save the map as an image
  plot_path <- "data/plots/Big Picture/Plot 1 - Universities Map.jpeg"
  ggsave(plot_path, plot = g, width = 10, height = 6, dpi = 300)
}

#Function 2: get the distribution of university types.
plot_university_types <- function(file_path) {
  # Step 1: Load the data from the "tidy_dataset.csv" file
  universities_df <- read.csv(file_path, stringsAsFactors = FALSE)
  
  # Step 2: Define regular expressions for each type (case-insensitive and word boundary)
  private_regex <- "(?i)\\bprivate\\b"
  public_regex <- "(?i)\\bpublic\\b"
  
  # Step 3: Extract information from the "description" column and categorize universities
  extract_type <- function(typeUni) {
    if (is.na(typeUni)) {
      return("NA")
    } else if (grepl(private_regex, typeUni, ignore.case = TRUE)) {
      return("Private")
    } else if (grepl(public_regex, typeUni, ignore.case = TRUE)) {
      return("Public")
    } else {
      return("Other")
    }
  }
  
  # Apply the function to the data frame using sapply
  universities_df$type <- sapply(universities_df$typeUni, extract_type)
  
  # Step 4: Create the plot using ggplot2
  # Count the number of universities for each type
  type_counts <- table(universities_df$type)
  
  # Calculate the total count of universities
  total_universities <- sum(type_counts)
  
  # Calculate percentages for each type
  percentages <- type_counts / total_universities * 100
  
  # Create a data frame for plotting, including all four categories
  plot_data <- data.frame(Type = c("Private", "Public", "Other", "NA"), Percentage = c(percentages["Private"], percentages["Public"], percentages["Other"], percentages["NA"]))
  
  # Create the round diagram (pie chart) using ggplot2
  pie_chart <- ggplot(plot_data, aes(x = "", y = Percentage, fill = Type)) +
    geom_bar(stat = "identity", width = 1) +
    coord_polar("y", start = 0) +
    scale_fill_manual(values = c("Private" = "#FF9900", "Public" = "#0099CC", "Other" = "#66CC66", "NA" = "#CCCCCC")) +
    labs(title = "Percentage of University Types",
         x = NULL,
         y = NULL,
         fill = "Type") +
    theme_void()
  
  # Print the pie chart
  print(pie_chart)
  
  # Save the pie chart as an image
  plot_path <- "data/plots/Big Picture/Plot 2 - University Type.jpeg"
  ggsave(plot_path, plot = pie_chart, width = 10, height = 6, dpi = 300)
}

#Function 3: get the temporal dimension of the data
plot_temporal_distribution <- function(file_path) {
  # Step 1: Read the tidy dataset
  top_universities_dataset <- read.csv(file_path)
  
  # Step 2: Convert the "founding_date" column to Date format
  top_universities_dataset$founding_date <- as.Date(paste0(top_universities_dataset$founding_date, "-01-01"))
  
  # Step 3: Filter out rows with missing founding dates
  top_universities_dataset <- top_universities_dataset %>%
    filter(!is.na(founding_date))
  
  # Step 4: Create the time series plot using ggplot2
  plot_temporal <- top_universities_dataset %>%
    ggplot(aes(x = founding_date)) +
    geom_histogram(binwidth = 365, fill = "steelblue") +
    labs(title = "Temporal Distribution of University Founding Dates",
         x = "Founding Date",
         y = "Number of Universities") +
    theme_minimal()
  
  # Step 5: Display the time series plot
  print(plot_temporal)
  
  # Save the time series plot as an image
  plot_path <- "data/plots/Big Picture/Plot 3 - Temporal Dimension of the Data.jpeg"
  ggsave(plot_path, plot = plot_temporal, width = 10, height = 6, dpi = 300)
}

#Function 4: Mean Ranking by Number of Students

plot_mean_ranking_by_students <- function(file_path) {
  # Step 1: Load the data from the "tidy_dataset.csv" file
  universities_df <- read.csv(file_path, stringsAsFactors = FALSE)
  
  # Step 2: Parse number of students values
  parse_students <- function(students) {
    if (is.na(students)) {
      return(NA)
    } else {
      # Extract only digits and remove any commas
      students <- str_remove_all(students, "[^0-9]")
      return(as.numeric(students))
    }
  }
  
  # Step 3: Apply the function to the number_of_students column
  universities_df$number_of_students_parsed <- sapply(universities_df$number_of_students, parse_students)
  
  # Step 4: Manually specify the labels for number of students bins
  students_bins <- c("<10,000", "10,000-25,000", "25,000-40,000", ">40,000")
  
  # Step 5: Create bins for number of students ranges
  universities_df$students_bin <- cut(
    universities_df$number_of_students_parsed, 
    breaks = c(0, 10000, 25000, 40000, Inf), 
    include.lowest = TRUE, 
    labels = students_bins
  )
  
  # Step 6: Calculate the mean ranking for each unique students_bin
  mean_ranking_students_data <- universities_df %>%
    filter(!is.na(number_of_students_parsed)) %>%
    group_by(students_bin) %>%
    summarize(mean_ranking = mean(ranking, na.rm = TRUE))
  
  # Step 7: Create the bar plot for number of students range using ggplot2
  bar_plot_students <- ggplot(mean_ranking_students_data, aes(x = students_bin, y = mean_ranking)) +
    geom_bar(stat = "identity", fill = "steelblue") +
    labs(title = "Mean Ranking by Number of Students Range",
         x = "Number of Students",
         y = "Mean Ranking",
         fill = "Number of Students Range") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
  # Step 8: Save the number of students range plot as an image
  plot_path_students <- "data/plots/Big Picture/Plot 4 - Mean Ranking vs. Number of Students.jpeg"
  ggsave(plot_path_students, plot = bar_plot_students, width = 10, height = 6, dpi = 300)
  
  # Step 9: Print the number of students range bar plot
  print(bar_plot_students)
}

####7: EXPLORATORY ANALYSIS####

#Function 1: Number of Students in Type of University
plot_students_by_university_type <- function(file_path) {
  # Step 1: Read the tidy dataset
  top_universities_dataset <- read.csv(file_path)
  
  # Step 2: Filter out rows with missing values for "number_of_students" and "typeUni" columns
  filtered_dataset <- top_universities_dataset %>%
    filter(!is.na(number_of_students) & !is.na(typeUni))
  
  # Step 3: Define regular expressions for each type (case-insensitive and word boundary)
  private_regex <- "(?i)\\bprivate\\b"
  public_regex <- "(?i)\\bpublic\\b"
  
  # Step 4: Extract information from the "typeUni" column and categorize universities
  extract_type <- function(typeUni) {
    if (is.na(typeUni)) {
      return("NA")
    } else if (grepl(private_regex, typeUni, ignore.case = TRUE)) {
      return("Private")
    } else if (grepl(public_regex, typeUni, ignore.case = TRUE)) {
      return("Public")
    } else {
      return("Other")
    }
  }
  
  # Apply the function to the data frame using sapply
  filtered_dataset$type <- sapply(filtered_dataset$typeUni, extract_type)
  
  # Step 5: Parse number of students values
  parse_students <- function(students) {
    if (is.na(students)) {
      return(NA)
    } else {
      # Remove commas from the number string and convert it to numeric
      students <- as.numeric(gsub(",", "", students))
      return(students)
    }
  }
  
  # Step 6: Apply the function to the number_of_students column
  filtered_dataset$number_of_students_parsed <- sapply(filtered_dataset$number_of_students, parse_students)
  
  # Step 7: Calculate the number of students in each type of university
  students_by_type <- filtered_dataset %>%
    group_by(type) %>%
    summarize(Total_Students = sum(number_of_students_parsed, na.rm = TRUE))
  
  # Step 8: Calculate the percentage distribution of students in each type of university
  total_students <- sum(students_by_type$Total_Students)
  students_by_type <- students_by_type %>%
    mutate(Percentage = (Total_Students / total_students) * 100)
  
  # Step 9: Create the bar plot using ggplot2
  bar_plot_students_by_type <- ggplot(students_by_type, aes(x = type, y = Percentage, fill = type)) +
    geom_bar(stat = "identity") +
    labs(title = "Percentage Distribution of Number of Students in Type of University",
         x = "Type of University",
         y = "Percentage",
         fill = "Type") +
    theme_minimal()
  
  # Step 10: Save the plot as an image
  plot_path_students_by_type <- "data/plots/Exploratory Analysis/Plot 1 - Percentage Distribution of Number of Students by University Type.jpeg"
  ggsave(plot_path_students_by_type, plot = bar_plot_students_by_type, width = 10, height = 6, dpi = 300)
  
  # Step 11: Print the bar plot
  print(bar_plot_students_by_type)
}

#Function 2: University type by Ranking Range
plot_university_types_by_ranking <- function(file_path) {
  # Step 1: Load the data from the "tidy_dataset.csv" file
  universities_df <- read.csv(file_path, stringsAsFactors = FALSE)
  
  # Step 2: Define regular expressions for each type (case-insensitive and word boundary)
  private_regex <- "(?i)\\bprivate\\b"
  public_regex <- "(?i)\\bpublic\\b"
  
  # Step 3: Extract information from the "description" column and categorize universities
  extract_type <- function(typeUni) {
    if (is.na(typeUni)) {
      return("NA")
    } else if (grepl(private_regex, typeUni, ignore.case = TRUE)) {
      return("Private")
    } else if (grepl(public_regex, typeUni, ignore.case = TRUE)) {
      return("Public")
    } else {
      return("Other")
    }
  }
  
  # Apply the function to the data frame using sapply
  universities_df$type <- sapply(universities_df$typeUni, extract_type)
  
  # Step 4: Filter out rows where the ranking is NA
  universities_df <- universities_df[!is.na(universities_df$ranking), ]
  
  # Step 5: Create bins for ranking ranges, including 1900-2000
  ranking_bins <- cut(
    universities_df$ranking,
    breaks = c(seq(1, 2000, by = 100), max(universities_df$ranking)),
    include.lowest = TRUE,
    labels = FALSE
  )
  
  # Step 6: Calculate the percentage of each university type within each ranking range and convert it to a 0-100 scale
  percentage_data <- universities_df %>%
    group_by(ranking_bin = ranking_bins, type) %>%
    summarize(Percentage = (n() / nrow(.)) * 2000, .groups = 'drop') %>%
    ungroup() %>%
    mutate(ranking_bin = as.numeric(ranking_bin),
           ranking_bin_label = paste((ranking_bin * 100) - 99, "-", ranking_bin * 100))
  
  # Step 7: Convert ranking_bin_label to factor and set levels to order them correctly
  percentage_data$ranking_bin_label <- factor(percentage_data$ranking_bin_label, levels = unique(percentage_data$ranking_bin_label))
  
  # Step 8: Sort the data frame by the ranking_bin column
  percentage_data <- percentage_data[order(percentage_data$ranking_bin), ]
  
  # Step 9: Create the bar plot using ggplot2 
  bar_plot <- ggplot(percentage_data, aes(x = ranking_bin_label, y = Percentage, fill = type)) +
    geom_bar(stat = "identity", position = "stack") +
    labs(title = "Percentage of University Types by Ranking Range",
         x = "Ranking Range",
         y = "Percentage",
         fill = "Type") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
  # Step 10: Save the plot as an image
  plot_path <- "data/plots/Exploratory Analysis/Plot 2 - Ranking vs. Type of University.jpeg"
  ggsave(plot_path, plot = bar_plot, width = 10, height = 6, dpi = 300)
  
  # Step 11: Print the bar plot
  print(bar_plot)
}

#Function 3: Percentage of private universities per country.
plot_private_universities_map <- function(file_path) {
  # Load the CSV file containing the top universities data
  top_universities_df <- read.csv(file_path, stringsAsFactors = FALSE)
  
  # Replace "usa" with "United States of America" in top_universities_df
  top_universities_df$location <- ifelse(tolower(top_universities_df$location) == "usa", "United States", top_universities_df$location)
  
  # Get the world map data
  worldMap_df <- ne_countries(scale = "medium", returnclass = "sf")
  
  # Clean up the location column in top_universities_df to match the names in worldMap_df
  # Assuming location in top_universities_df is the same as the name in worldMap_df
  top_universities_df$location <- tolower(top_universities_df$location)
  worldMap_df$name <- tolower(worldMap_df$name)
  
  # Create the country_counts_df with all countries and set universities to 0
  country_counts_df <- data.frame(name = worldMap_df$name, universities = 0)
  
  # Compute universities count for countries with data
  country_counts <- table(top_universities_df$location)
  country_counts_df$universities <- as.numeric(country_counts[match(country_counts_df$name, names(country_counts))])
  
  # Perform an inner join to keep only countries with matching keys in both dataframes
  joined_map_data <- inner_join(worldMap_df, country_counts_df, by = "name")
  
  # Compute percentage of private typeUni for each location
  private_typeUni_percentage_data <- top_universities_df %>%
    filter(grepl("(?i)private", typeUni)) %>%
    group_by(location) %>%
    summarize(Percentage_Private_TypeUni = (n() / nrow(.)) * 100) %>%
    ungroup()
  
  # Update the percentage in joined_map_data based on the computed percentages
  joined_map_data$Percentage_Private_TypeUni <- private_typeUni_percentage_data$Percentage_Private_TypeUni[match(joined_map_data$name, private_typeUni_percentage_data$location)]
  
  # Create the map plot
  g <- ggplot(data = joined_map_data) +
    geom_sf(aes(fill = Percentage_Private_TypeUni), color = "white") +
    scale_fill_gradient(low = "#C0C0FF", high = "#0000FF", name = "Percentage of Private TypeUni",
                        labels = scales::percent_format(scale = 1, zero.indicator = "0%")) +
    theme_void() +
    theme(legend.position = "bottom", legend.key.width = unit(2, "cm"))
  
  # Titles and captions
  g <- g +
    ggtitle("Countries with the Highest Percentage of Private Type Universities") +
    labs(subtitle = "Percentage of Private type of university",
         caption = "Data source: CWUR Universities")  # Add a caption with the data source if desired
  
  # Save the map as an image
  plot_path <- "data/plots/Exploratory Analysis/Plot 3- Universities Map by Percentage of Private TypeUni.jpeg"
  ggsave(plot_path, plot = g, width = 10, height = 6, dpi = 300)
  
  # Print the map plot
  print(g)
}