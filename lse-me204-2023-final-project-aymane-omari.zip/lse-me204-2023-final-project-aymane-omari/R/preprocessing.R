library(tidyverse)

process_enriched_data_to_tidy <- function(input_file_path, output_file_path) {
  # Read the CSV file
  data <- read.csv(input_file_path)
  
  # Replace "description" with "tid" content where necessary
  data$description <- ifelse(substr(data$description, 1, 5) == "list(", data$tid, data$description)
  
  # Keep only the specified columns
  columns_to_keep <- c("ranking", "name","location", "title", "description", "typeUni", "founding_date", "number_of_students")
  data_tidy <- data[, columns_to_keep]
  
  # Rename the "name" column to "link_access"
  colnames(data_tidy)[colnames(data_tidy) == "name"] <- "link_access"
  colnames(data_tidy)[colnames(data_tidy) == "title"] <- "name"
  
  # Save the tidy dataset as a new CSV file
  write.csv(data_tidy, file = output_file_path, row.names = FALSE)
}